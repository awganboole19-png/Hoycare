const translations = {
  "so": {
    "search": "Raadi adeegyada",
    "hero": "Daryeel caafimaad oo gurigaaga ah",
    "quickBook": "Dalbo adeeg",
    "nurse": "La hadal kalkaaliso",
    "services": "Adeegyadeenna",
    "demoNote": "Nooc tijaabo ah. Dalabyada xarunta looma diro.",
    "booking": "Ballamaha",
    "warning": "Tijaabo keliya. Ha gelin xog caafimaad oo gaar ah.",
    "service": "Adeegga",
    "date": "Taariikhda",
    "time": "Waqtiga",
    "save": "Kaydi ballan tijaabo ah",
    "myBookings": "Ballamahayga",
    "messages": "Farriimaha",
    "msgInfo": "Si aad ula xidhiidho HOYCARE, wac 3117.",
    "profile": "Akoonka",
    "profileInfo": "Diiwaangelinta akoonnada weli lama hawlgelin.",
    "home": "Bogga hore",
    "soon": "Dhawaan",
    "select": "Dooro adeeg",
    "empty": "Weli ballan ma jirto.",
    "past": "Dooro waqti mustaqbalka ah.",
    "saved": "Ballanta tijaabada ah waa la kaydiyey.",
    "callNow": "Wac 3117",
    "noResults": "Adeeg la mid ah lama helin.",
    "storageError": "Ballanta laguma kaydin karin qalabkan.",
    "localBooking": "Ballan tijaabo ah oo qalabkan ku kaydsan"
  },
  "en": {
    "search": "Search services",
    "hero": "Healthcare in the comfort of your home",
    "quickBook": "Book service",
    "nurse": "Ask a nurse",
    "services": "Our Services",
    "demoNote": "Demo only: bookings are not sent to HOYCARE.",
    "booking": "Bookings",
    "warning": "Demo only: do not enter private health information.",
    "service": "Service",
    "date": "Date",
    "time": "Time",
    "save": "Save demo booking",
    "myBookings": "My bookings",
    "messages": "Messages",
    "msgInfo": "Call 3117 to reach HOYCARE.",
    "profile": "Profile",
    "profileInfo": "Account registration is not available yet.",
    "home": "Home",
    "soon": "Soon",
    "select": "Choose service",
    "empty": "No bookings yet.",
    "past": "Please select a future time.",
    "saved": "Demo booking saved.",
    "callNow": "Call 3117",
    "noResults": "No matching services.",
    "storageError": "The booking could not be saved on this device.",
    "localBooking": "Demo booking saved on this device"
  }
};

const services = [
  { id: 'nursing', icon: '🏠', so: 'Kalkaalinta Guriga', en: 'Home Nursing', color: '#dff6f1', bookable: true },
  { id: 'caregiver', icon: '👩‍⚕️', so: 'Daryeelka Bukaanka', en: 'Caregiver Support', color: '#fff0d0', bookable: true },
  { id: 'lab', icon: '🧪', so: 'Shaybaadh', en: 'Laboratory (Home Sample)', color: '#eee8ff', bookable: true },
  { id: 'pharmacy', icon: '💊', so: 'Farmashiye', en: 'Pharmacy (Home Delivery)', color: '#fce8ef', bookable: true },
  { id: 'physio', icon: '🧘', so: 'Jimicsiga Daaweynta', en: 'Physiotherapy', color: '#edf2f5', bookable: false },
  { id: 'doctor', icon: '🩺', so: 'Dhakhtar Guriga', en: 'Doctor Home Visit', color: '#edf2f5', bookable: false }
];

const storageKey = 'hoycare-design-demo-v1';
const byId = id => document.getElementById(id);
const tabs = document.querySelectorAll('[data-tab]');
const search = byId('search');
const serviceField = byId('service');
const dateField = byId('date');
const timeField = byId('time');
const feedback = byId('feedback');
let language = 'so';
let feedbackKey = '';

function showPage(id) {
  for (const tab of tabs) {
    const selected = tab.dataset.tab === id;
    byId(tab.dataset.tab).hidden = !selected;
    if (selected) {
      tab.setAttribute('aria-current', 'page');
    } else {
      tab.removeAttribute('aria-current');
    }
  }
  if (id === 'book') renderBookings();
  window.scrollTo(0, 0);
}

function renderServices() {
  const grid = byId('grid');
  const query = search.value.trim().toLowerCase();
  grid.replaceChildren();

  for (const service of services) {
    if (![service.so, service.en].some(name => name.toLowerCase().includes(query))) continue;
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'service';
    card.disabled = !service.bookable;
    card.style.setProperty('--tile', service.color);

    const icon = document.createElement('span');
    icon.className = 'service-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = service.icon;

    const name = document.createElement('span');
    name.textContent = service[language];
    card.append(icon, name);

    if (service.bookable) {
      card.addEventListener('click', () => {
        serviceField.value = service.id;
        showPage('book');
        serviceField.focus({ preventScroll: true });
      });
    } else {
      const badge = document.createElement('span');
      badge.className = 'soon';
      badge.textContent = translations[language].soon;
      card.append(badge);
    }
    grid.append(card);
  }
  byId('noResults').hidden = grid.childElementCount > 0;
}

function readBookings() {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) ?? '[]');
    return Array.isArray(saved) ? saved.filter(booking => booking && typeof booking === 'object') : [];
  } catch {
    return [];
  }
}

function renderBookings() {
  const list = byId('bookingList');
  list.replaceChildren();

  for (const booking of readBookings().reverse()) {
    const service = services.find(item => item.id === booking.service);
    if (!service) continue;

    const card = document.createElement('article');
    card.className = 'booking';
    const title = document.createElement('strong');
    title.textContent = service[language];
    const date = document.createElement('p');
    date.textContent = booking.date + ' · ' + booking.time;
    const status = document.createElement('small');
    status.textContent = translations[language].localBooking;
    card.append(title, date, status);
    list.append(card);
  }

  if (!list.childElementCount) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.textContent = translations[language].empty;
    list.append(empty);
  }
}

function renderLanguage() {
  const text = translations[language];
  document.documentElement.lang = language;
  for (const element of document.querySelectorAll('[data-i]')) {
    element.textContent = text[element.dataset.i];
  }
  byId('so').setAttribute('aria-pressed', String(language === 'so'));
  byId('en').setAttribute('aria-pressed', String(language === 'en'));
  search.placeholder = text.search;

  const selection = serviceField.value;
  const placeholder = new Option(text.select, '');
  placeholder.disabled = true;
  serviceField.replaceChildren(placeholder);
  for (const service of services.filter(item => item.bookable)) {
    serviceField.add(new Option(service[language], service.id));
  }
  serviceField.value = selection;
  feedback.textContent = text[feedbackKey] ?? '';

  renderServices();
  renderBookings();
}

function showFeedback(key, error) {
  feedbackKey = key;
  feedback.dataset.error = String(error);
  feedback.textContent = translations[language][key];
}

function setBookingDateMinimum() {
  const today = new Date();
  today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
  dateField.min = today.toISOString().slice(0, 10);
}

for (const code of ['so', 'en']) {
  byId(code).addEventListener('click', () => {
    language = code;
    renderLanguage();
  });
}
for (const tab of tabs) {
  tab.addEventListener('click', () => showPage(tab.dataset.tab));
}

search.addEventListener('input', renderServices);
byId('quickBook').addEventListener('click', () => showPage('book'));
byId('nurse').addEventListener('click', () => showPage('messages'));
dateField.addEventListener('focus', setBookingDateMinimum);

byId('form').addEventListener('submit', event => {
  event.preventDefault();
  const service = serviceField.value;
  const date = dateField.value;
  const time = timeField.value;
  const appointment = new Date(date + 'T' + time);

  if (!services.some(item => item.bookable && item.id === service)) return;
  if (Number.isNaN(appointment.getTime()) || appointment <= new Date()) {
    showFeedback('past', true);
    return;
  }

  const bookings = readBookings();
  bookings.push({ service, date, time });
  try {
    localStorage.setItem(storageKey, JSON.stringify(bookings));
  } catch {
    showFeedback('storageError', true);
    return;
  }
  event.currentTarget.reset();
  serviceField.value = '';
  showFeedback('saved', false);
  renderBookings();
});

setBookingDateMinimum();
renderLanguage();

if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
  navigator.serviceWorker.register('./sw.js').catch(error => {
    console.warn('HOYCARE offline installation failed.', error);
  });
}
