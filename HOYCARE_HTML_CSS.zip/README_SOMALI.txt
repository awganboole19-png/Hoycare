HOYCARE · App-ka bukaanka

1. Ka fur ZIP-ka oo ka saar faylasha (Extract).
2. Naqshadda ku eeg adigoo Chrome ku furaya index.html.
3. Si aad GitHub Pages ugu cusboonaysiiso, geli faylasha gudaha ZIP-ka
   isla meesha index.html-ka hadda yaallo. Geli galka assets/ oo dhan.
4. Marka GitHub Pages dhammeeyo daabacaadda, fur link-ga HOYCARE ee
   Chrome oo dib u cusboonaysii. Kadib fur HOYCARE ee shaashadda hore.

Wac 3117 wuxuu furayaa meesha wicitaanka ee telefoonka.
Ballamaha tijaabada ah waxay ku kaydsamaan qalabka aad isticmaalayso.
