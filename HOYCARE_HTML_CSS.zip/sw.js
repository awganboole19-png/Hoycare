const cachePrefix = 'hoycare-patient:' + self.registration.scope;
const cacheName = cachePrefix + ':2026-11-html-css-1';
const appFiles = [
  './',
  './index.html',
  './style.css',
  './app.js',
  './manifest.webmanifest',
  './assets/logo.png',
  './assets/care.jpg',
  './assets/icon-192.png',
  './assets/icon-512.png'
];
const appURLs = new Set(appFiles.map(file => new URL(file, self.registration.scope).href));

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(cacheName).then(cache => cache.addAll(appFiles)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    const oldCaches = keys.filter(key => key.startsWith(cachePrefix + ':') && key !== cacheName);
    await Promise.all(oldCaches.map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  url.search = '';
  if (request.method !== 'GET' || !appURLs.has(url.href)) return;

  event.respondWith((async () => {
    try {
      return await fetch(request);
    } catch {
      const cache = await caches.open(cacheName);
      return (await cache.match(url.href)) ?? Response.error();
    }
  })());
});
